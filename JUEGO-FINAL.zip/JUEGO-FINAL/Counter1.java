import greenfoot.*;
 // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class Counter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Counter1 extends Actor
{
    int contar = 0;
    
    /**
     * Act - do whatever the Counter wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
    GreenfootImage image = new GreenfootImage("Fichas obtenidas: "+contar, 30, Color.WHITE,Color.BLACK);
        setImage(image);
        if (contar==28)
        {
             Greenfoot.stop();
             Greenfoot.playSound("win.mp3");
             Greenfoot.setWorld(new nivel_fin());
    }
    }
    
    public void addcontar()
    {
        contar++;
    }
}
