import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class yellow here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class yellow extends Actor
{
    /**
     * Act - do whatever the yellow wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int timer = 3600;
    public void act()
    {
        getImage().setTransparency(0);
        
        timer--;
        if (timer / 60 <= 50 && timer / 60 > 40)
        {
            getImage().setTransparency(255);
        }
        
        if (timer / 60 <= 30 && timer / 60 > 20)
        {
            getImage().setTransparency(255);
        }
    }
}
