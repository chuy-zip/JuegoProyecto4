import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class nivel_2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class nivel_2 extends World
{
    /**
     * Constructor for objects of class nivel_2.
     * 
     */

    public nivel_2()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        bus_goal bus_goal = new bus_goal();
        addObject(bus_goal,329,217);
        bus_goal.setLocation(530,320);
        
        turtle turtle = new turtle();
        addObject(turtle,329,217);
        turtle.setLocation(10,320);
        
        eagle eagle = new eagle();
        addObject(eagle,329,217);
        eagle.setLocation(10,100);
        
        green green = new green();
        addObject(green,560,100);
  
        yellow yellow = new yellow();
        addObject(yellow,520,100);
        
        
        red red = new red();
        addObject(red,480,100);
        
        showText("Presiona espacio rápido para \navanzar cuando no esté en rojo",300,50);
        
        
    }
       int timer = 3600;
    public void act()
    {
        timer--;
        if (timer % 60==0) 
        {
            showText("Time left: " + (timer/60),520,40);
        }
        
        if (timer <= 0)
        {
            showText("Intentalo de nuevo",300,200);
            Greenfoot.playSound("hit.mp3");
            Greenfoot.setWorld(new nivel_2());
        }
    
    }
}
