import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class to here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class to extends Actor
{
   private final int gravedad =1;
   private int velocidad;
   public to(){
       velocidad=0;
    }
    
    public void act()
    {
        moveAndTurn();
        eat();
        caida();
        if (Greenfoot.isKeyDown("space") && getY() > getWorld().getHeight()-50) 
        {
            Greenfoot.playSound("jump.mp3");
            jump();
        }
    }
    public void caida(){
        setLocation(getX(), getY()+velocidad);
        if(getY()>getWorld().getHeight()-50) velocidad=0;
        else velocidad += gravedad;
        
    }
    public void jump(){
        velocidad =-20;
    }
    public void move(){
        int y =getY();
        int x =getX();
    
    }
    public void moveAndTurn()
    {
      if (Greenfoot.isKeyDown("left"))
      {
          move(-3);
      }
      if (Greenfoot.isKeyDown("right"))
      {
          move(3);
      }
    }
     public void eat()
    {
             if (this.getOneIntersectingObject(pp.class) != null)
        {
            getWorld().removeObjects(getWorld().getObjects(co.class));
        }
    }
    
}
    

