import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class pp here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class pp extends Actor
{

    public void act()
    {
        moveAround();
        eat();
    }
    
    public void moveAround()
    {
        move(3);
        
        if (Greenfoot.getRandomNumber(100)<10)
        {
           turn(Greenfoot.getRandomNumber(90)-45);
        }
        if (getX() <=5 || getX() >= getWorld().getWidth()-5)
        {
            turn(180);
            
        }
         if (getY() <=5 || getY() >= getWorld().getWidth()-5)
        {
            turn(180);
            
        }
    
    }
    
    public void eat()
    {
        Actor TO;
        Actor CO;
      TO = getOneObjectAtOffset(0, 0, to.class);
     
        if (TO != null)
        {
            World world;
            world = getWorld();
            getWorld().addObject(new YouLose(), 218, 212);
            world.removeObject(this);
            Greenfoot.playSound("hit.mp3");
            Greenfoot.setWorld(new nivel_1());
    }
             }
        
    

}