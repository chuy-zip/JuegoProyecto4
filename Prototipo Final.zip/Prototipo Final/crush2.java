import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class crush2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class crush2 extends Actor
{
    Counter monedaCount = new Counter();
    /**
     * Act - do whatever the crush2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        monedaCount.setValue(0);
        movimiento();
        eat();
    }
    public void movimiento()
    {            
        int y = getY();
        if (Greenfoot.isKeyDown("right"))
        {
            move(2);
        }
         if (Greenfoot.isKeyDown("left"))
        {
            move(-2);
        }
         if (Greenfoot.isKeyDown("up"))
        {
            y--; 
        }
         if (Greenfoot.isKeyDown("down"))
        {
            y++;
        }
        setLocation(getX(), y);
    }
    public void eat()
    {
        Actor coin2;
        coin2 = getOneObjectAtOffset(0, 0, coin2.class);
        if(coin2 != null)
        {
            World world;
            world = getWorld();
            world.removeObject(coin2);
            monedaCount.add(1);
        }
        if (monedaCount.getValue() == 27)
                {
                    Greenfoot.setWorld(new nivel_fin());
                }
    }
}
