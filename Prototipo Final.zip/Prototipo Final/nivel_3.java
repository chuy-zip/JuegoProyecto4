import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class fondo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class nivel_3 extends World
{
    /**
     * Constructor for objects of class fondo.
     * 
     */
    public nivel_3()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 450, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        crush2 crush2 = new crush2();
        addObject(crush2,30,329);
        llama2 llama2 = new llama2();
        addObject(llama2,685,255);
        llama2.setLocation(685,255);
        coin2 coin2 = new coin2();
        addObject(coin2,600,346);
        coin2 coin22 = new coin2();
        addObject(coin22,550,346);
        coin2 coin23 = new coin2();
        addObject(coin23,500,346);
        coin2 coin24 = new coin2();
        addObject(coin24,450,346);
        coin2 coin25 = new coin2();
        addObject(coin25,400,346);
        coin24.setLocation(450,346);
        coin23.setLocation(400,346);
        coin2 coin26 = new coin2();
        addObject(coin26,350,346);
        coin2 coin27 = new coin2();
        addObject(coin27,300,346);
        coin2 coin28 = new coin2();
        addObject(coin28,250,346);
        coin2 coin29 = new coin2();
        addObject(coin29,200,346);
        coin29.setLocation(200,346);
        coin2 coin210 = new coin2();
        addObject(coin210,150,346);
        coin2 coin211 = new coin2();
        addObject(coin211,175,310);
        coin2 coin212 = new coin2();
        addObject(coin212,275,310);
        coin2 coin213 = new coin2();
        addObject(coin213,325,310);
        coin212.setLocation(275,310);
        coin213.setLocation(325,310);
        coin212.setLocation(275,310);
        coin2 coin214 = new coin2();
        addObject(coin214,375,310);
        coin2 coin215 = new coin2();
        addObject(coin215,425,310);
        coin2 coin216 = new coin2();
        addObject(coin216,475,310);
        coin2 coin217 = new coin2();
        addObject(coin217,525,310);
        coin2 coin218 = new coin2();
        addObject(coin218,575,310);
        coin2 coin219 = new coin2();
        addObject(coin219,575,310);
        coin2 coin220 = new coin2();
        addObject(coin220,675,310);
        coin2 coin221 = new coin2();
        addObject(coin221,200,270);
        coin2 coin222 = new coin2();
        addObject(coin222,250,270);
        coin2 coin223 = new coin2();
        addObject(coin223,300,270);
        coin2 coin224 = new coin2();
        addObject(coin224,350,270);
        coin2 coin225 = new coin2();
        addObject(coin225,400,270);
        coin2 coin226 = new coin2();
        addObject(coin226,450,270);
        coin226.setLocation(450,270);
        coin2 coin227 = new coin2();
        addObject(coin227,500,270);
        coin2 coin228 = new coin2();
        addObject(coin228,550,270);
        coin227.setLocation(500,270);
        coin218.setLocation(500,346);
        coin2 coin229 = new coin2();
        addObject(coin229,225,310);
        removeObject(coin220);
    }
}
