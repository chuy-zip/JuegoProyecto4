import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase "turtle", hecha por Ricardo Chuy
 * Controla el movimiento de la tortuga y cuando se llega a la meta
 */
public class turtle extends Actor
{
    /**
     * Act - do whatever the turtle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public void act()
    {
        GreenfootImage image = getImage();  
        image.scale(75, 75);
        setImage(image);
        
        //Solo se puede mover presionando espacio reptidamente
        String key = Greenfoot.getKey();
        if("space".equals(key))
        {
            move(3);
        }
        // Al cruzar cierta distancia se completa el nivel y se pasa al siguiente
        if(getX() >= 500)
        {
            Greenfoot.playSound("levelwin.mp3");
            Greenfoot.setWorld(new nivel_3());
        }
    }
    
    
}
