import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Esta es la clase del primer nivel, realizado por Diederich Solis
 */ 

public class nivel_1 extends World
{
    // Se utilizan las funcionalidades de "simple timer", que se pueden exportar de greenfoot    
    SimpleTimer tim = new SimpleTimer();
    Counter timeCount = new Counter();
    int start =1;
    int sum=0;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public nivel_1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 450, 1); 
        addObject(timeCount, getWidth() / 2, getHeight() / 2);
        tim.mark();
        timeCount.setValue(60);
        prepare();
        showText("Muevete con las flechas y \nsalta con el espacio",400,50);
    }

    public void act()
    {
        // En esta función es que va llevando el control del temporizador
        if (start == 1)
        {
            if (tim.millisElapsed()>1000)
            {
                timeCount.add(-1);
                tim.mark();
                
                // Si se acaba el tiempo, se avanza al siguiente nivel (El punto del nivel es sobrevivir)
                if (timeCount.getValue() == 0)
                {
                    Greenfoot.playSound("levelwin.mp3");
                    Greenfoot.setWorld(new nivel_2());
                }
            }

        }
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    //Función para preparar todos los objetos que se usaran en la pantalla
    private void prepare()
    {
        co co = new co();
        addObject(co,758,14);
        co co2 = new co();
        addObject(co2,729,13);
        co co3 = new co();
        addObject(co3,701,12);
        V v = new V();
        addObject(v,728,355);
        vi vi = new vi();
        addObject(vi,638,415);
        vi vi2 = new vi();
        addObject(vi2,622,371);
        vi vi3 = new vi();
        addObject(vi3,575,408);
        pp pp = new pp();
        addObject(pp,558,347);
        pp pp2 = new pp();
        addObject(pp2,578,370);
        pp pp3 = new pp();
        addObject(pp3,517,400);
        to to = new to();
        addObject(to,43,378);
        pp pp4 = new pp();
        addObject(pp4,505,358);
        v.setLocation(682,417);
        vi vi4 = new vi();
        addObject(vi4,682,417);
        v.setLocation(762,331);
        vi.setLocation(611,434);
        vi4.setLocation(661,396);
        co2.setLocation(724,6);
        removeObject(co2);
        co3.setLocation(706,8);
        removeObject(co3);
    }
}

