import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase "to", realizado por Diederich Solis
 * Este es el personaje principal que controla el jugador
 */
public class to extends Actor
{
   private final int gravedad =1;
   private int velocidad;
   public to(){
       velocidad=0;
    }
    //Control principal, al presionar espacio se salta y se produce sonido
    public void act()
    {
        moveAndTurn();
        eat();
        caida();
        if (Greenfoot.isKeyDown("space") && getY() > getWorld().getHeight()-50) 
        {
            Greenfoot.playSound("jump.mp3");
            jump();
        }
    }
    //Calculo de caida y velocidad
    public void caida(){
        setLocation(getX(), getY()+velocidad);
        if(getY()>getWorld().getHeight()-50) velocidad=0;
        else velocidad += gravedad;
        
    }
   //Salto y detección de posición
    public void jump(){
        velocidad =-20;
    }
    public void move(){
        int y =getY();
        int x =getX();
    
    }
    //Movimiento a la izquierda y derecha
    public void moveAndTurn()
    {
      if (Greenfoot.isKeyDown("left"))
      {
          move(-3);
      }
      if (Greenfoot.isKeyDown("right"))
      {
          move(3);
      }
    }
    //Detección de colisión 
    public void eat()
    {
             if (this.getOneIntersectingObject(pp.class) != null)
        {
            getWorld().removeObjects(getWorld().getObjects(co.class));
        }
    }
    
}
    

