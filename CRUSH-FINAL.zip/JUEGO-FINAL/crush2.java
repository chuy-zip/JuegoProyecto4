import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Controles de la tortuga en el nivel final, Por Pablo Alvarez
 */
public class crush2 extends Actor
{
    /**
     * Act - do whatever the crush2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        //Movimientos y acciones de las tortugas
        movimiento();
        eat();
    }
    public void movimiento()
    {            
        int y = getY();
        // Movimiento hacia la derecha e izquierda
        if (Greenfoot.isKeyDown("right"))
        {
            move(4);
        }
         if (Greenfoot.isKeyDown("left"))
        {
            move(-4);
        }
        // Movimiento hacia arriba y hacia abajo
         if (Greenfoot.isKeyDown("up"))
        {
            y--; 
        }
         if (Greenfoot.isKeyDown("down"))
        {
            y++;
        }
        //Mover a la localización de x con y modificado por el movimiento
        setLocation(getX(), y);
    }
    public void eat()
    {
        //Función que detecta colisiones entre la tortuga y las moendas
        Actor coin2;
        coin2 = getOneObjectAtOffset(0, 0, coin2.class);
        if(coin2 != null)
        {
            //Se remueve la moneda
            World world;
            world = getWorld();
            world.removeObject(coin2);
            
            //Obtener el contador y actualizarlo
            nivel_3 mundo = (nivel_3)world;
            Counter1 cont = mundo.getCounter();
            cont.addcontar();
            
            //Sonido al recoger moneda
            Greenfoot.playSound("coins.mp3");
        }
    }
     
}
