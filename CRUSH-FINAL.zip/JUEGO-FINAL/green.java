import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class green here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class green extends Actor
{
    /**
     * Act - do whatever the green wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    //Aqui también se tiene el contador de frames para mostrarlo en segundos
    int timer = 3600;
    public void act()
    {
        //Cada frame se resta 1 al contador
        timer--;
        // El semáforo está en verde de 60 a 50
        // Luego de 50 a 35 desaparece porque estará en amarillo y luego en rojo
        if (timer / 60 <= 50 && timer / 60 > 35)
        {
            getImage().setTransparency(0);
        }
        // El semáforo está en verde de 35 a 30
        if (timer / 60 <= 35 && timer / 60 >= 30)
        {
            getImage().setTransparency(255);
        }
        // Luego de 30 a 10 desaparece porque estará en amarillo y luego en rojo
        if (timer / 60 <= 30 && timer / 60 >= 10)
        {
            getImage().setTransparency(0); 
        }
        // Por último 
        if (timer / 60 <= 10 && timer / 60 >= 0)
        {
            getImage().setTransparency(255);
        }
    }
}
