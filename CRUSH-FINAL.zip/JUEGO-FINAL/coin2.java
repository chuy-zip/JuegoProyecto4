import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase "coin2", monedas que se recolectan por el jugador
 */
public class coin2 extends Actor
{
    /**
     * Las monedas no realizan acciones
     */
    public void act()
    {
        // Add your action code here.
    }
}
