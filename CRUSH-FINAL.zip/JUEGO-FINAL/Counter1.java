import greenfoot.*;
 // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Contador de monedas, implementado por Diederich Solis
 */
public class Counter1 extends Actor
{
    int contar = 0;
    
    /**
     * Esta parte muestra en tiempo real la cantidad de monedas reclectadas
     */
    public void act()
    {
        GreenfootImage image = new GreenfootImage("Fichas obtenidas: "+contar, 30, Color.WHITE,Color.BLACK);
            setImage(image);
            if (contar==28)
            {
                 Greenfoot.stop();
                 Greenfoot.playSound("win.mp3");
                 Greenfoot.setWorld(new nivel_fin());
        }
    }
    
    public void addcontar()
    {
        // Sumatoria al contador
        contar++;
    }
}
