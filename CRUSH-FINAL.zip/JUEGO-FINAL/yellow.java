import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase "yellow", hecha por Ricardo Chuy
 * Indicador amarillo de precaución al jugador
 */

public class yellow extends Actor
{
    /**
     * Clase "yellow", hecha por Ricardo Chuy
     * Muestra la figura amarilla, indicando precaución al jugador
     */
    //Aqui también se tiene el contador de frames para mostrarlo en segundos
    int timer = 3600;
    public void act()
    {
        getImage().setTransparency(0);
        //Cada frame se resta 1 al contador
        timer--;
        //Mostrar el amarillo de 50 a 40 segundos
        if (timer / 60 <= 50 && timer / 60 > 40)
        {
            getImage().setTransparency(255);
        }
        //Mostrar el amarillo de 30 a 20 segundos
        if (timer / 60 <= 30 && timer / 60 > 20)
        {
            getImage().setTransparency(255);
        }
    }
}
