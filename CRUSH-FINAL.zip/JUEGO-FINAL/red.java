import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class red here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class red extends Actor
{
    /**
     * Act - do whatever the red wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    //Aqui también se tiene el contador de frames para mostrarlo en segundos
    int timer = 3600;
    public void act()
    {
        getImage().setTransparency(0);
        //Cada frame se resta 1 al contador
        timer--;
        // Mostrar rojo de 40 a 30 segundos
        if (timer / 60 <= 40 && timer / 60 > 35)
        {
            getImage().setTransparency(255);
            if (Greenfoot.isKeyDown("space"))
            {
                //Si se detecta movimiento se reinicia el nivel
                Greenfoot.playSound("hit.mp3");
                Greenfoot.setWorld(new nivel_2());
            }
        }
        // Mostrar rojo de 20 a 10 segundos
        if (timer / 60 <= 20 && timer / 60 > 10)
        {
            getImage().setTransparency(255);
            //Si se detecta movimiento se reinicia el nivel
            if (Greenfoot.isKeyDown("space"))
            {
                Greenfoot.playSound("hit.mp3");
                Greenfoot.setWorld(new nivel_2());
            }
        }
    }
}
