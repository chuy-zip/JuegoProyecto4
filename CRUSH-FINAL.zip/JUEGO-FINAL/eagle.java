import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase "eagle", hecha por Ricardo Chuy
 * Este es la competencia de la tortuga al autobus, llega en exactamente 60 segundos
 */
public class eagle extends SmoothMover
{
    /**
     * Act - do whatever the eagle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        GreenfootImage image = getImage();  
        image.scale(75, 75);
        setImage(image);
        //Con la aydua de Smoothmover es posible moverse menos de 1 pixel por fram
        move(0.15);
    }
    

}
