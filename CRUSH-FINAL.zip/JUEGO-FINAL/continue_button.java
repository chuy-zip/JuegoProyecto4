import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 *En esta parte del codigo tenemos el boton de inicio, que con un clic lleva a la siguiente pantalla (Nivel 1)
 *Traslado de prototipo de papel a codigo por Fabiola Deras
 */
public class continue_button extends Actor
{
    /**
     * Act - do whatever the continue_button wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        //Se ajusta tamaño y posición
        GreenfootImage image = getImage();  
        image.scale(100, 100);
        setImage(image);
        
        //Al detectar un nivel avanza al nivel indicado
        if (Greenfoot.mousePressed(this))
        {
            Greenfoot.playSound("levelwin.mp3");
            Greenfoot.setWorld(new nivel_1());
        }
    }
}
