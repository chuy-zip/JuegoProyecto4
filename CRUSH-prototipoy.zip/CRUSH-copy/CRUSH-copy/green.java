import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class green here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class green extends Actor
{
    /**
     * Act - do whatever the green wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int timer = 3600;
    public void act()
    {
        timer--;
        if (timer / 60 <= 50 && timer / 60 > 35)
        {
            getImage().setTransparency(0);
        }
        
        if (timer / 60 <= 35 && timer / 60 >= 30)
        {
            getImage().setTransparency(255);
        }
        
        if (timer / 60 <= 30 && timer / 60 >= 10)
        {
            getImage().setTransparency(0); 
        }
        
        if (timer / 60 <= 10 && timer / 60 >= 0)
        {
            getImage().setTransparency(255);
        }
    }
}
