import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class bus_goal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class bus_goal extends Actor
{
    /**
     * Act - do whatever the bus_goal wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        GreenfootImage image = getImage();  
        image.scale(150, 150);
        setImage(image);
    }
}
