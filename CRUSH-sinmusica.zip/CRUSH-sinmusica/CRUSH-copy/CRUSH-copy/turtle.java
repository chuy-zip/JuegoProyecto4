import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class turtle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class turtle extends Actor
{
    /**
     * Act - do whatever the turtle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public void act()
    {
        GreenfootImage image = getImage();  
        image.scale(75, 75);
        setImage(image);
        
        String key = Greenfoot.getKey();
        if("space".equals(key))
        {
            move(3);
        }

        if(getX() >= 500)
        {
            Greenfoot.setWorld(new nivel_3());
        }
    }
    
    
}
