import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class continue_button here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class continue_button extends Actor
{
    /**
     * Act - do whatever the continue_button wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        GreenfootImage image = getImage();  
        image.scale(100, 100);
        setImage(image);
        
        if (Greenfoot.mousePressed(this))
        {
            Greenfoot.setWorld(new nivel_2());
        }
    }
}
