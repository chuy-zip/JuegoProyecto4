import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class red here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class red extends Actor
{
    /**
     * Act - do whatever the red wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int timer = 3600;
    public void act()
    {
        getImage().setTransparency(0);
        
        timer--;
        if (timer / 60 <= 40 && timer / 60 > 35)
        {
            getImage().setTransparency(255);
        }
        
        if (timer / 60 <= 20 && timer / 60 > 10)
        {
            getImage().setTransparency(255);
        }
    }
}
